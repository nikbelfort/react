import React from 'react';
import Modal from 'react-modal';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import { Container, Row, Col, Button, Form, FormGroup, Label, Input, Table  } from 'reactstrap';

import {
    Collapse,
    Navbar,
    NavbarToggler,
    NavbarBrand,
    Nav,
    NavItem,
    NavLink,
    UncontrolledDropdown,
    DropdownToggle,
    DropdownMenu,
    DropdownItem } from 'reactstrap';

const customStyles = {
    content : {
      top                   : '50%',
      left                  : '50%',
      right                 : 'auto',
      bottom                : 'auto',
      marginRight           : '-50%',
      transform             : 'translate(-50%, -50%)'
    },
    mainComponent: {
       marginLeft:  '33%',
       marginTop:  '40px'
    }
  };
  const someStyle= {
      content: {
        top                   : '50%',
        left                  : '50%',
        right                 : 'auto',
        bottom                : 'auto',
        marginRight           : '-50%',
        transform             : 'translate(-50%, -50%)'

      }

    };
       
export default class form extends React.Component{
      
    constructor() {
        super();
    
        this.state = {
        modalIsOpen: false,
        products:[],
        product:{ 
        name: '',
        price: '',
        cakename: '',
        image:''
        },
        update:false,                 //initially set as false
        updateIndex:''
        };
    
        this.openModal = this.openModal.bind(this);
        this.afterOpenModal = this.afterOpenModal.bind(this);
        this.closeModal = this.closeModal.bind(this);
        }
    
        openModal() {
        this.setState({modalIsOpen: true});
        }
    
      afterOpenModal() {
        // references are now sync'd and can be accessed.
        // this.subtitle.style.color = '#f00';
      }
    
      closeModal() {
        this.setState({modalIsOpen: false});
      }

 
    componentWillMount(){

        const fetch = [JSON.parse(localStorage.getItem("user"))];
        
        if (fetch[0].length >=1)
        {
            this.setState({products:fetch});
        }
    }

    change =(e) => {                  //handling the change operations
      
        const product={...this.state.product};
        var name=e.target.name;
        if(name==="name")
        product.name=e.target.value;
        if(name==='price')
        product.price=e.target.value;
        if(name==='cakename')
        product.cakename=e.target.value ;
        this.setState({
              product:product
        });
    }

    handleSubmit= (e) => {              //handling the submit operations 
        e.preventDefault();
        const product={
            name: '',
            price: '',
            cakename: '',
            image:''
        }
        this.state.products.push(this.state.product);
        this.setState({product:product});
        localStorage.setItem('user',JSON.stringify(this.state.products));  //local storage used
        console.log(this.state.products);        
    }
    handleEdit= i=>{    
                       //handling the edit operations
        const product={
            ...this.state.products[i]
        }
        this.setState({product:product})
        this.setState({update:true})       //updating true so that the update button is visible
        this.setState({
            updateIndex:i
        })
       this.openModal();
    }
    handleUpdate=()=>{                   //handling the update operations
        const products=[...this.state.products];
        products[this.state.updateIndex]=this.state.product;
        this.setState({
            products:products
        })
        this.setState({
            update:false
        })
        const product={
            name: '',
            price: '',
            cakename: '',
            image:''
            
        }
        this.state.products.push(this.state.product);
        this.setState({product:product});
    }

    handleDelete= i=>{                //handling the delete operations
        const products=[
            ...this.state.products
    ]
        products.splice(i,1);
        this.setState({products:products});
        localStorage.setItem('user',JSON.stringify(products));
        console.log(products);
    }
    readImage(){                     //reading image
        const reader=new FileReader();
        const self= this;
        reader.onload=function(){
            self.state.product.image=reader.result;
        }
        reader.readAsDataURL(document.getElementById('image').files[0]);
    }
    


    render(){                     //rendering
        return(
            <div>
                <Navbar color="light" expand="md">
          <NavbarBrand href="/">CAKESHOP</NavbarBrand>
          <NavbarToggler onClick={this.toggle} />
          <Collapse isOpen={this.state.isOpen} navbar>
            <Nav className="ml-auto" navbar>
              <NavItem>
                <NavLink> </NavLink>
              </NavItem>
              <NavItem>
                <NavLink></NavLink>
              </NavItem>
              <UncontrolledDropdown nav inNavbar>
                <DropdownToggle nav caret>Options</DropdownToggle>
                <DropdownMenu right>
                  <DropdownItem>Login</DropdownItem>
                  <DropdownItem>SignUp</DropdownItem>
                  <DropdownItem divider />
                  <DropdownItem>Reset</DropdownItem>
                </DropdownMenu>
              </UncontrolledDropdown>
            </Nav>
          </Collapse>
        
        </Navbar>

            <button onClick={this.openModal} className="btn btn-primary" style={{marginTop: '15px'}}>Add Cake</button>
            <Modal 
            isOpen={this.state.modalIsOpen}
            onAfterOpen={this.afterOpenModal}
            onRequestClose={this.closeModal}
            style={customStyles}
            contentLabel="Example Modal"
            >
        <Form onSubmit={this.handleSubmit}>
        <FormGroup>
          <Label for="name">Name</Label>
          <Input type="text" name="name" id="name" placeholder="name"
                value={this.state.product.name} 
                onChange={this.change} 
                /> 
        </FormGroup> 
        <FormGroup>
          <Label for="price">Price</Label>
          <Input type="text" name="price" id="price" placeholder="price"
                value={this.state.product.price} 
                onChange={this.change} 
                /> 
        </FormGroup> 
        <FormGroup>
          <Label for="cakename">CakeName</Label>
          <Input type="text" name="cakename" id="cakename" placeholder="cakename"
                value={this.state.product.cakename} 
                onChange={this.change} 
                /> 
        </FormGroup>
        <FormGroup>
          <Label for="image">Image</Label>
          <Input type="file" name="myImage" id="image"
                onChange={()=>this.readImage()}
                accept='image/x-png,image/gif,image/jpeg'
                /> 
        </FormGroup>
                {this.state.update?null:<button className="btn btn-primary">Add</button>}
                {this.state.update?<button onClick={this.handleUpdate} className="btn btn-primary">Update</button>:null}
                <button onClick={this.closeModal} className="btn btn-danger" style={{marginLeft: '15px'}}>Close</button>
                
            </Form>
            </Modal>            
            <div style={{marginTop: '40px', marginLeft: '10px', marginRight: '10px'}} >
            <Table bordered>
            <thead>
            <tr>
                <th >Name</th>
                <th>Price</th>
                <th>Cakename</th>
                <th>Image</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>
            </thead>
            <tbody>
                
                { this.state.products.map((product,i)=>(
                    (this.state.products.length>=1) && (
                    <tr key={i} >
                    <td>{product.name}</td>
                    <td>{product.price}</td>   
                    <td>{product.cakename}</td>
                    <td width="100px"><div className="container con"><img width="100px" height="100px" src={product.image}/></div></td>
                    <td><input type="button" value="EDIT" className="btn btn-primary" onClick={()=>this.handleEdit(i)}/></td>
                    <td><input type="button" value="DELETE"  className="btn btn-danger" onClick={()=>this.handleDelete(i)}/></td> 
                    </tr> 
                    )                        
                ))}
            </tbody>
            </Table>
            </div>
            </div>
        );
    } 

}